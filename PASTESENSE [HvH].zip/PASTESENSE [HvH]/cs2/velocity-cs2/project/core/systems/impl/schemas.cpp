#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>

#include "../systems.hpp"

namespace {
	using schema_key_t = std::uint64_t;

	[[nodiscard]] inline schema_key_t make_schema_key( const char* class_name, std::uint32_t field_hash )
	{
		const auto class_hash = fnv1a::runtime_hash( class_name );
		return ( static_cast<schema_key_t>( class_hash ) << 32 ) | field_hash;
	}

	[[nodiscard]] inline bool read_name_and_offset(
		std::uintptr_t field_addr,
		std::uintptr_t& name_ptr,
		std::uint32_t& offset )
	{
		name_ptr = memory::safe_read<std::uintptr_t>( field_addr ).value_or( 0 );
		if ( !name_ptr )
		{
			return false;
		}

		offset = memory::safe_read<std::uint32_t>( field_addr + 0x10 ).value_or( 0 );
		if ( !offset )
		{
			offset = memory::safe_read<std::uint32_t>( field_addr + 0x18 ).value_or( 0 );
		}

		return true;
	}
}

namespace systems {

	std::uint32_t schemas::lookup( const char* class_name, std::uint32_t field_hash )
	{
		if ( !class_name || !*class_name )
		{
			return 0;
		}

		static std::mutex schema_cache_mtx{};
		static std::unordered_map<schema_key_t, std::uint32_t> schema_cache{};

		const auto key = make_schema_key( class_name, field_hash );
		{
			std::scoped_lock lock( schema_cache_mtx );
			const auto it = schema_cache.find( key );
			if ( it != schema_cache.end() )
			{
				return it->second;
			}
		}

		const auto type_scope = memory::call_vfunc<std::uintptr_t>( addresses::globals::schema_system, 13, xs( "client.dll" ), nullptr );
		if ( !type_scope )
		{
			return 0;
		}

		auto class_info{ 0ull };
		memory::call_vfunc<void>( type_scope, 2, &class_info, class_name );
		if ( !class_info )
		{
			return 0;
		}

		std::array<std::ptrdiff_t, 6> field_ptr_offsets{ { 0x30, 0x38, 0x40, 0x48, 0x50, 0x58 } };
		std::array<std::ptrdiff_t, 6> field_count_offsets{ { 0x24, 0x18, 0x1c, 0x20, 0x28, 0x30 } };

		std::uintptr_t fields_ptr{};
		std::uint16_t field_count{};
		bool resolved{};

		for ( const auto field_ptr_offset : field_ptr_offsets )
		{
			fields_ptr = memory::safe_read<std::uintptr_t>( class_info + field_ptr_offset ).value_or( 0 );
			if ( !fields_ptr )
			{
				continue;
			}

			for ( const auto field_count_offset : field_count_offsets )
			{
				field_count = memory::safe_read<std::uint16_t>( class_info + field_count_offset ).value_or( 0 );
				if ( field_count )
				{
					resolved = true;
					goto found_fields;
				}
			}
		}

	found_fields:
		if ( !resolved || !fields_ptr || !field_count )
		{
			return 0;
		}

		for ( std::uint16_t i = 0; i < field_count; ++i )
		{
			const auto field_addr = fields_ptr + ( static_cast< std::size_t >( i ) * 0x20 );
			std::uintptr_t name_ptr{};
			std::uint32_t offset{};

			if ( !read_name_and_offset( field_addr, name_ptr, offset ) )
			{
				continue;
			}

			if ( fnv1a::runtime_hash( reinterpret_cast< const char* >( name_ptr ) ) == field_hash )
			{
				std::scoped_lock lock( schema_cache_mtx );
				schema_cache[key] = offset;
				return offset;
			}
		}

		return 0;
	}

} // namespace systems