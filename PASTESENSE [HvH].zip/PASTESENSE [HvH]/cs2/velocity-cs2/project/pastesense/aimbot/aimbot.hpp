#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace pastesense::aimbot {

    enum class hitbox_id : std::uint8_t {
        head,
        neck,
        chest,
        stomach,
        pelvis,
        arms,
        legs,
        count
    };

    enum class target_priority : std::uint8_t {
        distance,
        fov,
        health,
        damage,
        lethality,
        threat,
        visibility,
        hitrate,
        anti_aim,
        weighted
    };

    struct hitbox_weight {
        float head{ 1.0f };
        float neck{ 0.95f };
        float chest{ 0.85f };
        float stomach{ 0.8f };
        float pelvis{ 0.7f };
        float arms{ 0.5f };
        float legs{ 0.45f };
    };

    struct multipoint_config {
        float base_scale{ 1.0f };
        float head_scale{ 1.0f };
        float body_scale{ 0.7f };
        float damage_scale{ 0.0f };
        float visibility_scale{ 0.0f };
        bool head_priority{ true };
        bool body_priority{ false };
    };

    struct target_score {
        std::uint32_t entity_index{ 0 };
        float distance{ 0.0f };
        float fov{ 0.0f };
        float health{ 0.0f };
        float damage_potential{ 0.0f };
        float lethality{ 0.0f };
        float threat{ 0.0f };
        float visibility{ 0.0f };
        float hit_history{ 0.0f };
        float anti_aim_pressure{ 0.0f };
        float weighted_score{ 0.0f };
    };

    class target_selector {
    public:
        void set_priority_weighting(float distance, float fov, float health, float damage, float lethality,
            float threat, float visibility, float hitrate, float anti_aim) {
            this->m_weights = { distance, fov, health, damage, lethality, threat, visibility, hitrate, anti_aim };
        }

        target_score evaluate(std::uint32_t entity_index, float distance, float fov, float health,
            float damage_potential, float lethality, float threat, float visibility,
            float hit_history, float anti_aim_pressure) const {
            target_score score{};
            score.entity_index = entity_index;
            score.distance = distance;
            score.fov = fov;
            score.health = health;
            score.damage_potential = damage_potential;
            score.lethality = lethality;
            score.threat = threat;
            score.visibility = visibility;
            score.hit_history = hit_history;
            score.anti_aim_pressure = anti_aim_pressure;
            score.weighted_score =
                distance * this->m_weights[0] +
                fov * this->m_weights[1] +
                health * this->m_weights[2] +
                damage_potential * this->m_weights[3] +
                lethality * this->m_weights[4] +
                threat * this->m_weights[5] +
                visibility * this->m_weights[6] +
                hit_history * this->m_weights[7] +
                anti_aim_pressure * this->m_weights[8];
            return score;
        }

    private:
        std::array<float, 9> m_weights{ 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
    };

    class ragebot_system {
    public:
        void set_hitbox_weights(const hitbox_weight& weights) {
            this->m_hitbox_weights = weights;
        }

        void set_multipoint(const multipoint_config& config) {
            this->m_multipoint = config;
        }

        const hitbox_weight& hitbox_weights() const {
            return this->m_hitbox_weights;
        }

        const multipoint_config& multipoint() const {
            return this->m_multipoint;
        }

    private:
        hitbox_weight m_hitbox_weights{};
        multipoint_config m_multipoint{};
    };

} // namespace pastesense::aimbot
