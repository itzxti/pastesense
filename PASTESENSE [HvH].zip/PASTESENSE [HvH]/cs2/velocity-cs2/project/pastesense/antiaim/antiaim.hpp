#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace pastesense::antiaim {

    enum class anti_aim_state : std::uint8_t {
        standing,
        walking,
        running,
        slow_walk,
        crouching,
        airborne,
        landing,
        shooting,
        post_shot,
        low_hp,
        manual_override
    };

    struct pattern_step {
        std::uint32_t tick_start{ 0 };
        std::uint32_t tick_end{ 0 };
        float yaw{ 0.0f };
        bool randomize{ false };
        std::string label;
    };

    struct anti_aim_config {
        float yaw{ 0.0f };
        float jitter{ 0.0f };
        float jitter_range{ 0.0f };
        float jitter_speed{ 0.0f };
        float pitch{ 0.0f };
        bool freestanding{ false };
        bool body_orientation{ false };
        bool deterministic{ true };
        bool randomize{ false };
    };

    class pattern_generator {
    public:
        void add_step(std::uint32_t start, std::uint32_t end, float yaw, const std::string& label, bool randomize = false) {
            this->m_steps.push_back({ start, end, yaw, randomize, label });
        }

        const std::vector<pattern_step>& steps() const {
            return this->m_steps;
        }

    private:
        std::vector<pattern_step> m_steps{};
    };

    class anti_aim_state_machine {
    public:
        void set_state(anti_aim_state state) {
            this->m_state = state;
        }

        anti_aim_state state() const {
            return this->m_state;
        }

        void configure(const anti_aim_config& config) {
            this->m_config = config;
        }

        const anti_aim_config& config() const {
            return this->m_config;
        }

    private:
        anti_aim_state m_state{ anti_aim_state::standing };
        anti_aim_config m_config{};
    };

    inline anti_aim_state_machine g_state_machine{};

} // namespace pastesense::antiaim
