#pragma once

#include <algorithm>
#include <array>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace pastesense::config {

    enum class profile_mode : std::uint8_t {
        aggressive,
        safe,
        awp,
        scout,
        rifle,
        pistol,
        anti_jitter,
        anti_spin,
        adaptive,
        experimental
    };

    struct weapon_profile {
        std::string name;
        float hitchance{ 0.0f };
        float min_damage{ 0.0f };
        float point_scale{ 0.0f };
        float autostop_strength{ 0.0f };
        float resolver_bias{ 0.0f };
    };

    class profile_manager {
    public:
        profile_manager() {
            this->register_weapon("default", { "default", 82.0f, 30.0f, 88.0f, 0.74f, 0.52f });
            this->register_weapon("awp", { "awp", 94.0f, 120.0f, 100.0f, 0.9f, 0.76f });
            this->register_weapon("scout", { "scout", 90.0f, 90.0f, 96.0f, 0.82f, 0.72f });
            this->register_weapon("rifle", { "rifle", 84.0f, 52.0f, 88.0f, 0.72f, 0.6f });
            this->register_weapon("pistol", { "pistol", 74.0f, 20.0f, 72.0f, 0.42f, 0.46f });
            this->register_weapon("smg", { "smg", 76.0f, 24.0f, 78.0f, 0.54f, 0.5f });
            this->register_weapon("heavy", { "heavy", 86.0f, 60.0f, 92.0f, 0.8f, 0.7f });
        }

        void set_active(profile_mode mode) {
            this->m_active = mode;
        }

        void set_active_index(int index) {
            const auto clamped = std::clamp(index, 0, 9);
            this->m_active = static_cast<profile_mode>(clamped);
        }

        profile_mode active() const {
            return this->m_active;
        }

        const weapon_profile& current_profile() const {
            switch (this->m_active) {
            case profile_mode::aggressive: return this->m_mode_profiles[0];
            case profile_mode::safe: return this->m_mode_profiles[1];
            case profile_mode::awp: return this->m_mode_profiles[2];
            case profile_mode::scout: return this->m_mode_profiles[3];
            case profile_mode::rifle: return this->m_mode_profiles[4];
            case profile_mode::pistol: return this->m_mode_profiles[5];
            case profile_mode::anti_jitter: return this->m_mode_profiles[6];
            case profile_mode::anti_spin: return this->m_mode_profiles[7];
            case profile_mode::adaptive: return this->m_mode_profiles[8];
            case profile_mode::experimental: return this->m_mode_profiles[9];
            default: return this->m_mode_profiles[8];
            }
        }

        weapon_profile& current_profile_mutable() {
            switch (this->m_active) {
            case profile_mode::aggressive: return this->m_mode_profiles[0];
            case profile_mode::safe: return this->m_mode_profiles[1];
            case profile_mode::awp: return this->m_mode_profiles[2];
            case profile_mode::scout: return this->m_mode_profiles[3];
            case profile_mode::rifle: return this->m_mode_profiles[4];
            case profile_mode::pistol: return this->m_mode_profiles[5];
            case profile_mode::anti_jitter: return this->m_mode_profiles[6];
            case profile_mode::anti_spin: return this->m_mode_profiles[7];
            case profile_mode::adaptive: return this->m_mode_profiles[8];
            case profile_mode::experimental: return this->m_mode_profiles[9];
            default: return this->m_mode_profiles[8];
            }
        }

        void register_weapon(const std::string& weapon_name, const weapon_profile& profile) {
            this->m_weapon_profiles[weapon_name] = profile;
        }

        const weapon_profile* weapon_profile_for(const std::string& weapon_name) const {
            const auto it = this->m_weapon_profiles.find(weapon_name);
            return it != this->m_weapon_profiles.end() ? &it->second : nullptr;
        }

        const weapon_profile& profile_for_mode(profile_mode mode) const {
            switch (mode) {
            case profile_mode::aggressive: return this->m_mode_profiles[0];
            case profile_mode::safe: return this->m_mode_profiles[1];
            case profile_mode::awp: return this->m_mode_profiles[2];
            case profile_mode::scout: return this->m_mode_profiles[3];
            case profile_mode::rifle: return this->m_mode_profiles[4];
            case profile_mode::pistol: return this->m_mode_profiles[5];
            case profile_mode::anti_jitter: return this->m_mode_profiles[6];
            case profile_mode::anti_spin: return this->m_mode_profiles[7];
            case profile_mode::adaptive: return this->m_mode_profiles[8];
            case profile_mode::experimental: return this->m_mode_profiles[9];
            default: return this->m_mode_profiles[8];
            }
        }

        weapon_profile& profile_for_mode_mutable(profile_mode mode) {
            switch (mode) {
            case profile_mode::aggressive: return this->m_mode_profiles[0];
            case profile_mode::safe: return this->m_mode_profiles[1];
            case profile_mode::awp: return this->m_mode_profiles[2];
            case profile_mode::scout: return this->m_mode_profiles[3];
            case profile_mode::rifle: return this->m_mode_profiles[4];
            case profile_mode::pistol: return this->m_mode_profiles[5];
            case profile_mode::anti_jitter: return this->m_mode_profiles[6];
            case profile_mode::anti_spin: return this->m_mode_profiles[7];
            case profile_mode::adaptive: return this->m_mode_profiles[8];
            case profile_mode::experimental: return this->m_mode_profiles[9];
            default: return this->m_mode_profiles[8];
            }
        }

        const weapon_profile& resolve_for_weapon(std::uint32_t weapon_type, std::uint16_t item_def_idx = 0) const {
            if (item_def_idx == 9 || item_def_idx == 40) {
                return this->m_mode_profiles[2];
            }

            if (item_def_idx == 8 || item_def_idx == 39 || item_def_idx == 60) {
                return this->m_mode_profiles[4];
            }

            switch (weapon_type) {
            case 1: return this->m_mode_profiles[5];
            case 2: return this->m_mode_profiles[4];
            case 3: return this->m_mode_profiles[4];
            case 4: return this->m_mode_profiles[0];
            case 5: return this->m_mode_profiles[3];
            case 6: return this->m_mode_profiles[9];
            default: break;
            }

            return this->current_profile();
        }

    private:
        profile_mode m_active{ profile_mode::adaptive };
        std::array<weapon_profile, 10> m_mode_profiles{
            weapon_profile{ "aggressive", 84.0f, 34.0f, 92.0f, 0.82f, 0.88f },
            weapon_profile{ "safe", 74.0f, 28.0f, 78.0f, 0.58f, 0.38f },
            weapon_profile{ "awp", 95.0f, 120.0f, 100.0f, 0.92f, 0.82f },
            weapon_profile{ "scout", 90.0f, 88.0f, 96.0f, 0.84f, 0.74f },
            weapon_profile{ "rifle", 83.0f, 52.0f, 88.0f, 0.7f, 0.62f },
            weapon_profile{ "pistol", 72.0f, 20.0f, 70.0f, 0.4f, 0.46f },
            weapon_profile{ "anti_jitter", 82.0f, 30.0f, 82.0f, 0.72f, 0.96f },
            weapon_profile{ "anti_spin", 80.0f, 28.0f, 80.0f, 0.66f, 0.84f },
            weapon_profile{ "adaptive", 82.0f, 32.0f, 86.0f, 0.76f, 0.68f },
            weapon_profile{ "experimental", 90.0f, 36.0f, 95.0f, 0.96f, 1.0f }
        };
        std::unordered_map<std::string, weapon_profile> m_weapon_profiles{};
    };

    inline profile_manager g_profile_manager{};

} // namespace pastesense::config
