#pragma once

#include <atomic>
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace pastesense::core {

    enum class lifecycle_state : std::uint8_t {
        uninitialized,
        initializing,
        ready,
        shutting_down,
        stopped
    };

    class ilifecycle {
    public:
        virtual ~ilifecycle() = default;
        virtual void initialize() = 0;
        virtual void shutdown() = 0;
        virtual lifecycle_state state() const = 0;
    };

    class service_container : public ilifecycle {
    public:
        service_container() = default;
        ~service_container() override = default;

        void initialize() override {
            this->m_state = lifecycle_state::ready;
        }

        void shutdown() override {
            this->m_state = lifecycle_state::stopped;
        }

        lifecycle_state state() const override {
            return this->m_state.load();
        }

    protected:
        std::atomic<lifecycle_state> m_state{ lifecycle_state::uninitialized };
    };

    struct system_runtime {
        std::uint32_t frame_id{ 0 };
        std::uint32_t tick_count{ 0 };
        std::uint64_t time_ms{ 0 };
    };

} // namespace pastesense::core
