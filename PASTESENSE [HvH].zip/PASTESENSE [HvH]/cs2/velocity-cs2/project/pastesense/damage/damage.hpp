#pragma once

#include <algorithm>
#include <array>
#include <cstdint>
#include <string>

namespace pastesense::damage {

    struct damage_snapshot {
        float expected_damage{ 0.0f };
        float minimum_damage{ 0.0f };
        bool lethal{ false };
        float target_hp{ 0.0f };
        float target_armor{ 0.0f };
        float armor_effectiveness{ 0.0f };
        bool helmet{ false };
    };

    class damage_simulator {
    public:
        damage_snapshot evaluate(float base_damage, float distance, float armor, float health, bool helmet, bool headshot) const {
            damage_snapshot snapshot{};
            snapshot.target_hp = health;
            snapshot.target_armor = armor;
            snapshot.helmet = helmet;

            const float distance_factor = std::max(0.0f, 1.0f - (distance / 4096.0f));
            float projected = base_damage * (0.5f + distance_factor);
            if (armor > 0.0f) {
                projected *= 1.0f - (0.25f * (armor / 100.0f));
                snapshot.armor_effectiveness = 0.25f * (armor / 100.0f);
            }

            if (headshot) {
                projected *= 1.35f;
            }

            snapshot.expected_damage = projected;
            snapshot.minimum_damage = std::max(0.0f, projected * 0.45f);
            snapshot.lethal = projected >= health;
            return snapshot;
        }

    private:
    };

} // namespace pastesense::damage
