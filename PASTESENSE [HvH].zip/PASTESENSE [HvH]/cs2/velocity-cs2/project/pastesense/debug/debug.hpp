#pragma once

#include <array>
#include <cstdint>
#include <string>

namespace pastesense::debug {

    struct overlay_toggle {
        bool player_hitboxes{ false };
        bool multipoints{ false };
        bool resolver_direction{ false };
        bool predicted_position{ false };
        bool current_target{ false };
        bool selected_point{ false };
        bool aim_position{ false };
        bool spread_cone{ false };
        bool shot_trajectory{ false };
        bool autostop_state{ false };
        bool anti_aim_state{ false };
    };

    class visual_debugger {
    public:
        void set_overlays(const overlay_toggle& toggle) {
            this->m_toggle = toggle;
        }

        const overlay_toggle& toggles() const {
            return this->m_toggle;
        }

    private:
        overlay_toggle m_toggle{};
    };

} // namespace pastesense::debug
