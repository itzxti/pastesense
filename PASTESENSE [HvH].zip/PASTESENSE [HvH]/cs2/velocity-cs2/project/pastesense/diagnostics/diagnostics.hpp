#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <unordered_map>

namespace pastesense::diagnostics {

    struct subsystem_status {
        std::string name;
        bool ok{ false };
    };

    class diagnostics_screen {
    public:
        void mark_ok(const std::string& name, bool ok) {
            this->m_status[name] = ok;
        }

        std::array<subsystem_status, 9> snapshot() const {
            std::array<subsystem_status, 9> result{};
            const std::array<std::string, 9> names = {
                "CS2 Build",
                "Schema",
                "Interfaces",
                "Renderer",
                "Entity System",
                "Prediction",
                "Aimbot",
                "Resolver",
                "Config"
            };

            for (std::size_t i = 0; i < names.size(); ++i) {
                result[i].name = names[i];
                result[i].ok = this->m_status.count(names[i]) ? this->m_status.at(names[i]) : false;
            }
            return result;
        }

    private:
        std::unordered_map<std::string, bool> m_status{};
    };

} // namespace pastesense::diagnostics
