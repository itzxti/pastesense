#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace pastesense::entities {

    enum class entity_type : std::uint8_t {
        unknown,
        player,
        item,
        projectile
    };

    struct entity_record {
        std::uint32_t handle{ 0 };
        std::uint32_t index{ 0 };
        std::uint64_t address{ 0 };
        entity_type type{ entity_type::unknown };
        bool alive{ false };
        bool dormant{ false };
        bool visible{ false };
        std::string schema_name;
    };

    class entity_manager {
    public:
        void register_entity(const entity_record& entity) {
            this->m_entities.push_back(entity);
            this->m_lookup[entity.handle] = entity.index;
        }

        const std::vector<entity_record>& entities() const {
            return this->m_entities;
        }

        std::uint32_t lookup_handle(std::uint32_t handle) const {
            const auto it = this->m_lookup.find(handle);
            return it != this->m_lookup.end() ? it->second : 0;
        }

    private:
        std::vector<entity_record> m_entities{};
        std::unordered_map<std::uint32_t, std::uint32_t> m_lookup{};
    };

} // namespace pastesense::entities
