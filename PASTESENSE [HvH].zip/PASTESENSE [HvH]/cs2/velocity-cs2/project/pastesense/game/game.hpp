#pragma once

#include "../core/core.hpp"
#include "../interfaces/interfaces.hpp"

namespace pastesense::game {

    class game_context final : public core::service_container {
    public:
        void initialize() override {
            this->m_state = core::lifecycle_state::initializing;
            this->m_state = core::lifecycle_state::ready;
        }

        void shutdown() override {
            this->m_state = core::lifecycle_state::shutting_down;
            this->m_state = core::lifecycle_state::stopped;
        }

        std::uint32_t tick() const {
            return this->m_tick;
        }

        void set_tick(std::uint32_t tick) {
            this->m_tick = tick;
        }

    private:
        std::uint32_t m_tick{ 0 };
    };

} // namespace pastesense::game
