#pragma once

#include <string>

namespace pastesense::gui {

    class hud_window {
    public:
        void render() {
            this->m_visible = true;
        }

        bool visible() const {
            return this->m_visible;
        }

    private:
        bool m_visible{ false };
    };

} // namespace pastesense::gui
