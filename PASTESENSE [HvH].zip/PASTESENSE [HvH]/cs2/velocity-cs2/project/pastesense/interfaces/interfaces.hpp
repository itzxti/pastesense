#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace pastesense::interfaces {

    struct vector3 {
        float x{};
        float y{};
        float z{};
    };

    struct hitbox_info {
        std::uint8_t index{};
        std::string name;
        vector3 center{};
        float radius{};
    };

    class i_game_system {
    public:
        virtual ~i_game_system() = default;
        virtual void update() = 0;
    };

    class i_entity {
    public:
        virtual ~i_entity() = default;
        virtual std::uint32_t handle() const = 0;
        virtual bool alive() const = 0;
        virtual std::uint8_t team() const = 0;
        virtual float health() const = 0;
        virtual vector3 origin() const = 0;
    };

    class i_weapon {
    public:
        virtual ~i_weapon() = default;
        virtual std::uint16_t item_definition_index() const = 0;
        virtual float spread() const = 0;
        virtual float inaccuracy() const = 0;
        virtual float max_range() const = 0;
    };

    class i_renderer {
    public:
        virtual ~i_renderer() = default;
        virtual void begin_frame() = 0;
        virtual void end_frame() = 0;
        virtual void draw_line(const vector3& a, const vector3& b, std::uint32_t color) = 0;
    };

    class i_gui {
    public:
        virtual ~i_gui() = default;
        virtual void render() = 0;
    };

} // namespace pastesense::interfaces
