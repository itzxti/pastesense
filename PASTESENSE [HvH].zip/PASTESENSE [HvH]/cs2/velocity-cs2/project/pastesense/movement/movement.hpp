#pragma once

#include <cstdint>
#include <string>

namespace pastesense::movement {

    enum class stop_mode : std::uint8_t {
        full_stop,
        directional_stop,
        counter_strafe,
        early_stop,
        late_stop
    };

    struct autostop_context {
        float current_velocity{ 0.0f };
        float target_distance{ 0.0f };
        float weapon_speed{ 0.0f };
        bool on_ground{ false };
        bool crouching{ false };
        std::uint32_t tick{ 0 };
        std::uint32_t desired_hitbox{ 0 };
    };

    class movement_optimizer {
    public:
        stop_mode select_mode(const autostop_context& ctx) const {
            if (ctx.target_distance < 200.0f && ctx.current_velocity > 120.0f) {
                return stop_mode::directional_stop;
            }
            if (ctx.tick % 2 == 0) {
                return stop_mode::counter_strafe;
            }
            return stop_mode::full_stop;
        }

        std::string mode_name(stop_mode mode) const {
            switch (mode) {
            case stop_mode::full_stop: return "Full Stop";
            case stop_mode::directional_stop: return "Directional Stop";
            case stop_mode::counter_strafe: return "Counter-strafe";
            case stop_mode::early_stop: return "Early Stop";
            case stop_mode::late_stop: return "Late Stop";
            }
            return "Unknown";
        }
    };

} // namespace pastesense::movement
