#pragma once

#include "core/core.hpp"
#include "game/game.hpp"
#include "entities/entities.hpp"
#include "schema/schema.hpp"
#include "interfaces/interfaces.hpp"
#include "renderer/renderer.hpp"
#include "gui/gui.hpp"
#include "aimbot/aimbot.hpp"
#include "resolver/resolver.hpp"
#include "antiaim/antiaim.hpp"
#include "prediction/prediction.hpp"
#include "movement/movement.hpp"
#include "damage/damage.hpp"
#include "weapons/weaponsystem.hpp"
#include "config/config.hpp"
#include "statistics/statistics.hpp"
#include "diagnostics/diagnostics.hpp"
#include "debug/debug.hpp"

namespace pastesense {

    class system final : public core::service_container {
    public:
        system() = default;
        ~system() override = default;

        void initialize() override {
            this->core::service_container::initialize();
        }

        void shutdown() override {
            this->core::service_container::shutdown();
        }
    };

} // namespace pastesense
