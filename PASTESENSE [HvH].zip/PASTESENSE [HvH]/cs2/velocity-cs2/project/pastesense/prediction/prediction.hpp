#pragma once

#include <array>
#include <cstdint>

namespace pastesense::prediction {

    struct entity_state {
        float x{ 0.0f };
        float y{ 0.0f };
        float z{ 0.0f };
        float velocity_x{ 0.0f };
        float velocity_y{ 0.0f };
        float velocity_z{ 0.0f };
        float yaw{ 0.0f };
        float pitch{ 0.0f };
        bool on_ground{ false };
        bool airborne{ false };
        bool crouching{ false };
    };

    struct prediction_result {
        entity_state location{};
        float error{ 0.0f };
        std::uint32_t tick{ 0 };
    };

    class predictor {
    public:
        prediction_result estimate(const entity_state& current, std::uint32_t future_ticks) const {
            prediction_result result{};
            result.location = current;
            result.location.x += current.velocity_x * static_cast<float>(future_ticks);
            result.location.y += current.velocity_y * static_cast<float>(future_ticks);
            result.location.z += current.velocity_z * static_cast<float>(future_ticks);
            result.tick = future_ticks;
            result.error = 0.0f;
            return result;
        }
    };

} // namespace pastesense::prediction
