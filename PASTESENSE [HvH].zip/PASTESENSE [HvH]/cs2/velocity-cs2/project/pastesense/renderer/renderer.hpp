#pragma once

#include <cstdint>

namespace pastesense::renderer {

    class renderer_context {
    public:
        void begin_frame() {
            this->m_frame_id++;
        }

        void end_frame() {
        }

        std::uint32_t frame_id() const {
            return this->m_frame_id;
        }

    private:
        std::uint32_t m_frame_id{ 0 };
    };

} // namespace pastesense::renderer
