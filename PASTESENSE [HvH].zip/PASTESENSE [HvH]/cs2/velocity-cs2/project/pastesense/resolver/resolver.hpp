#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace pastesense::resolver {

    enum class strategy : std::uint8_t {
        static_strategy,
        jitter,
        low_delta,
        high_delta,
        spin,
        freestanding,
        moving,
        standing,
        airborne,
        brute_force,
        adaptive
    };

    struct hypothesis {
        strategy type{ strategy::adaptive };
        float confidence{ 0.0f };
        std::uint32_t tick_seen{ 0 };
        std::uint32_t shot_count{ 0 };
        bool valid{ false };
    };

    struct enemy_snapshot {
        std::uint32_t entity_index{ 0 };
        float target_position_x{ 0.0f };
        float target_position_y{ 0.0f };
        float target_position_z{ 0.0f };
        float orientation_yaw{ 0.0f };
        float animation_delta{ 0.0f };
        bool moving{ false };
        bool airborne{ false };
        bool standing{ false };
        bool jittering{ false };
        std::uint32_t last_updated_tick{ 0 };
    };

    struct shot_result {
        std::uint32_t tick{ 0 };
        std::uint32_t target_index{ 0 };
        std::uint32_t hitbox{ 0 };
        bool hit{ false };
        float damage{ 0.0f };
        float hitchance{ 0.0f };
        std::string miss_reason;
    };

    class resolver_system {
    public:
        void update(const enemy_snapshot& snapshot) {
            this->m_previous = this->m_current;
            this->m_current = snapshot;
            this->reconsider_hypotheses();
        }

        void record_shot_result(const shot_result& result) {
            this->m_last_shot = result;

            for (auto& h : this->m_hypotheses) {
                h.confidence = std::max(0.0f, h.confidence * 0.97f);
            }

            if (result.hit) {
                this->m_hypotheses[static_cast<std::size_t>(strategy::jitter)].confidence += 0.24f;
                this->m_hypotheses[static_cast<std::size_t>(strategy::low_delta)].confidence += 0.12f;
                this->m_hypotheses[static_cast<std::size_t>(strategy::adaptive)].confidence += 0.18f;
            }
            else {
                this->m_hypotheses[static_cast<std::size_t>(strategy::jitter)].confidence -= 0.18f;
                this->m_hypotheses[static_cast<std::size_t>(strategy::freestanding)].confidence += 0.12f;
                this->m_hypotheses[static_cast<std::size_t>(strategy::spin)].confidence += 0.08f;
            }

            for (auto& h : this->m_hypotheses) {
                h.confidence = std::clamp(h.confidence, 0.0f, 1.0f);
            }
        }

        const std::array<hypothesis, 11>& hypotheses() const {
            return this->m_hypotheses;
        }

        strategy active_strategy() const {
            return this->m_active_strategy;
        }

        void set_active_strategy(strategy value) {
            this->m_active_strategy = value;
        }

    private:
        void reconsider_hypotheses() {
            const auto delta = std::fabsf(this->m_current.orientation_yaw - this->m_previous.orientation_yaw);

            for (auto& h : this->m_hypotheses) {
                h.confidence = std::max(0.0f, h.confidence * 0.98f);
            }

            this->m_hypotheses[static_cast<std::size_t>(strategy::jitter)].confidence = this->m_current.jittering ? 0.7f : 0.28f;
            this->m_hypotheses[static_cast<std::size_t>(strategy::freestanding)].confidence = this->m_current.standing ? 0.42f : 0.18f;
            this->m_hypotheses[static_cast<std::size_t>(strategy::moving)].confidence = this->m_current.moving ? 0.64f : 0.22f;
            this->m_hypotheses[static_cast<std::size_t>(strategy::standing)].confidence = this->m_current.standing ? 0.58f : 0.16f;
            this->m_hypotheses[static_cast<std::size_t>(strategy::airborne)].confidence = this->m_current.airborne ? 0.72f : 0.12f;
            this->m_hypotheses[static_cast<std::size_t>(strategy::adaptive)].confidence = std::clamp(0.32f + delta * 0.008f, 0.0f, 1.0f);
            this->m_hypotheses[static_cast<std::size_t>(strategy::static_strategy)].confidence = this->m_current.standing ? 0.26f : 0.08f;
            this->m_hypotheses[static_cast<std::size_t>(strategy::spin)].confidence = std::clamp(this->m_current.jittering ? 0.1f : 0.04f + delta * 0.006f, 0.0f, 0.7f);

            if (this->m_current.airborne) {
                this->m_active_strategy = strategy::airborne;
            }
            else if (this->m_current.jittering || this->m_hypotheses[static_cast<std::size_t>(strategy::jitter)].confidence > 0.55f) {
                this->m_active_strategy = strategy::jitter;
            }
            else if (this->m_current.moving || this->m_hypotheses[static_cast<std::size_t>(strategy::moving)].confidence > 0.5f) {
                this->m_active_strategy = strategy::moving;
            }
            else if (this->m_current.standing) {
                this->m_active_strategy = strategy::standing;
            }
            else {
                this->m_active_strategy = strategy::adaptive;
            }
        }

        enemy_snapshot m_current{};
        enemy_snapshot m_previous{};
        shot_result m_last_shot{};
        strategy m_active_strategy{ strategy::adaptive };
        std::array<hypothesis, 11> m_hypotheses{};
        std::array<float, 11> m_confidences{ 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
    };

} // namespace pastesense::resolver
