#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace pastesense::schema {

    struct class_field {
        std::string name;
        std::uint32_t offset{ 0 };
        std::uint32_t hash{ 0 };
        bool valid{ false };
    };

    class schema_registry {
    public:
        void register_field(const std::string& class_name, const class_field& field) {
            this->m_fields[class_name].push_back(field);
        }

        const std::vector<class_field>& fields_for(const std::string& class_name) const {
            static const std::vector<class_field> empty{};
            const auto it = this->m_fields.find(class_name);
            return it != this->m_fields.end() ? it->second : empty;
        }

        bool class_exists(const std::string& class_name) const {
            return this->m_fields.find(class_name) != this->m_fields.end();
        }

    private:
        std::unordered_map<std::string, std::vector<class_field>> m_fields{};
    };

} // namespace pastesense::schema
