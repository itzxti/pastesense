#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <unordered_map>

namespace pastesense::statistics {

    struct shot_record {
        std::uint64_t timestamp{ 0 };
        std::uint32_t target_index{ 0 };
        std::string weapon;
        float target_position_x{ 0.0f };
        float target_position_y{ 0.0f };
        float target_position_z{ 0.0f };
        float local_position_x{ 0.0f };
        float local_position_y{ 0.0f };
        float local_position_z{ 0.0f };
        float predicted_position_x{ 0.0f };
        float predicted_position_y{ 0.0f };
        float predicted_position_z{ 0.0f };
        float hitchance{ 0.0f };
        float expected_damage{ 0.0f };
        float actual_damage{ 0.0f };
        bool hit{ false };
        std::string miss_reason;
    };

    struct round_summary {
        float accuracy{ 0.0f };
        float resolver_success_rate{ 0.0f };
        std::uint32_t missed_shots{ 0 };
        std::uint32_t total_shots{ 0 };
        float average_damage{ 0.0f };
        float headshot_percentage{ 0.0f };
        std::unordered_map<std::string, std::uint32_t> miss_categories{};
    };

    class shot_analyzer {
    public:
        void record_shot(const shot_record& shot) {
            this->m_shots.push_back(shot);
            this->m_total_shots++;
            if (!shot.hit) {
                this->m_missed_shots++;
            }
        }

        round_summary summarize() const {
            round_summary summary{};
            summary.total_shots = static_cast<std::uint32_t>(this->m_shots.size());
            summary.missed_shots = this->m_missed_shots;
            summary.accuracy = (summary.total_shots == 0) ? 0.0f : (float)(summary.total_shots - summary.missed_shots) / (float)summary.total_shots;
            summary.resolver_success_rate = summary.accuracy;
            summary.average_damage = 0.0f;
            for (const auto& shot : this->m_shots) {
                summary.average_damage += shot.actual_damage;
            }
            if (!this->m_shots.empty()) {
                summary.average_damage /= static_cast<float>(this->m_shots.size());
            }
            return summary;
        }

    private:
        std::vector<shot_record> m_shots{};
        std::uint32_t m_total_shots{ 0 };
        std::uint32_t m_missed_shots{ 0 };
    };

} // namespace pastesense::statistics
