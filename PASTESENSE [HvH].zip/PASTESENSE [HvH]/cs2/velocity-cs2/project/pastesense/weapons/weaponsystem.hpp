#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <unordered_map>

namespace pastesense::weapons {

    enum class weapon_class : std::uint8_t {
        awp,
        scout,
        rifle,
        pistol,
        smg,
        shotgun,
        sniper,
        lmg
    };

    struct vehicle_weapon_profile {
        std::string name;
        float hitchance{ 0.0f };
        float min_damage{ 0.0f };
        float point_scale{ 0.0f };
        float autostop{ 0.0f };
        float target_priority{ 0.0f };
        float resolver_bias{ 0.0f };
    };

    class weapon_system {
    public:
        void register_profile(weapon_class type, const vehicle_weapon_profile& profile) {
            this->m_profiles[static_cast<std::size_t>(type)] = profile;
        }

        const vehicle_weapon_profile& profile_for(weapon_class type) const {
            return this->m_profiles[static_cast<std::size_t>(type)];
        }

    private:
        std::array<vehicle_weapon_profile, 8> m_profiles{};
    };

} // namespace pastesense::weapons
